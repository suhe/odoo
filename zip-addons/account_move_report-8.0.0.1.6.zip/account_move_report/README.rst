Journal Entries report
======================

This module adds a report in journal entries. You can print one o several
journal entries in PDF file.
