{
    "name":"Hirarki CoA",
    "version":"0.1",
    "author":"Muhammad Aziz - 087881071515",
    "website":"http://tutorialopenerp.wordpress.com",
    "category":"Custom Modules",
    "description": """
        The base module to generate CoA.
    """,
    "depends":["base", "account"],
    "init_xml":[],
    "demo_xml":[],
    "update_xml":["account_view.xml", "data_account_type.xml"],
    "active":False,
    "installable":True
}
