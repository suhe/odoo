# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'CoA UKM / Koperasi',
    'version': '1.1',
    'category': 'Localization/Account Charts',
    'description': """This is the base module to manage the generic accounting chart""",
    'author': 'Radio Rodja 756 AM',
    'depends': ['account', 'aa_account'],
    'data': [
        'configurable_account_chart.xml',
        'account_chart_template.yml',
    ],
    'test': [],
    'demo': [],
    'installable': True,
    'website': 'https://www.radiorodja.com',
}
