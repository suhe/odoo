# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import account_report_common_journal
import account_report_print_journal
import account_report_partner_ledger
